<?php
	include 'header.php';
	include 'navbar.php';
?>
				
					<div class="content mt-3">
						<div class="row">
							<div class="col-sm-3">								
								<div class="card">
									<div class="card-body bg-primary text-center">
										<h3>Peminjaman</h3>
										<?php
										include '../koneksi.php';
										$data_peminjaman = mysqli_query($koneksi,"SELECT * FROM peminjaman WHERE UserID= '".$_SESSION['UserID']."'");
										$jumlah_peminjaman = mysqli_num_rows($data_peminjaman);
										?>
										<h3><?php echo $jumlah_peminjaman; ?></h3>
										<a href="peminjaman.php" class="btn btn-dark btn-sm">Lihat Data</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="content mt-3">
							<div class="card">
								<div class="card-body">
								<p>Halo <b><?php echo $_SESSION['Username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['Level']; ?></b>.
								</p>
								</div>
							</div>
						</div>


<?php
	include 'footer.php';
?>

 